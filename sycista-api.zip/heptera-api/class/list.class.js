const listElement = class{




constructor(id) { 
	 this.list_conn = require("../confige/list.confige.js");
    this.id = id; 
    
    
  }


function GetListName(callback){

	

this.list_conn.query(`SELECT * FROM filedetails WHERE id = ${this.id}`, (err, results) => {
    

    callback(results);




   
  });




}

  DeleteList(){

return this.id;

  }

}

module.exports =listElement;