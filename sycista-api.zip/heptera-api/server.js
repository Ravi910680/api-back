const express = require("express");
const bodyParser = require("body-parser");



const app = express();


// parse requests of content-type: application/json


// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

app.use(bodyParser.json());

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
});






//test











//sending api content





app.post("/send/:lst_id/txt/:email/", (req, res) => {


oauth_tokn=req.header('authorization').split(" ")[1];


oauth_fun_tokn(oauth_tokn,2,function(id){






if(id!="false"){




lst_id=req.params.lst_id;
email=req.params.email;

get_email_data(lst_id,email,function(results){


if(results=='false'){


}else{


email_send_con=req.body;

email_send_con.email=email;

email_send_con.type_send="txt";

email_send_con.lst_id=lst_id;

data_of_usr_dyn=results;

const axios = require('axios');



axios.post('http://localhost/html/send-system/send-api.php',{
  data: email_send_con,oauth_tokn:oauth_tokn,usr_data:data_of_usr_dyn
})
  .then(response => {
    
    res.json(response.data);
  })
  .catch(error => {
    console.log(error);
  });

}

});



}else{


res.json("not Authorized request");



}

})

});






app.post("/send/:lst_id/template/:email/", (req, res) => {



oauth_tokn=req.header('authorization').split(" ")[1];

oauth_fun_tokn(oauth_tokn,2,function(id){






if(id!="false"){




lst_id=req.params.lst_id;
email=req.params.email;

get_email_data(lst_id,email,function(results){


if(results=='false'){



}else{



email_send_con=req.body;

email_send_con.email=email;

email_send_con.type_send="template";

email_send_con.lst_id=lst_id;

data_of_usr_dyn=results;


const axios = require('axios');

axios.post('http://localhost/html/send-system/send-api.php',{
  data: email_send_con,usr_data:data_of_usr_dyn,oauth_tokn:oauth_tokn
})
  .then(response => {
    
    res.json(response.data);
  })
  .catch(error => {
    console.log(error);
  });

}

});



}else{


res.json("not Authorized request");



}

})

});









// manage api content
app.get("/list", (req, res) => {

oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){






if(id!="false"){

const list_conn = require("./confige/list.confige.js");

list_conn.query(`SELECT * FROM filedetails WHERE id = ${id}`, (err, results) => {
    

       if (err) {
      console.log("error: ", err);
      
    }

   res.json(results);
      
    
});


}else{

res.json("not Authorized request");

}




  
});






});


app.get("/list/:lst_id/all", (req, res) => {




oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){






if(id!="false"){




const filecon_conn = require("./confige/filecon.confige.js");


console.log(req.params.lst_id);

filecon_conn.query('SELECT * FROM `'+req.params.lst_id+'`', (err, results) => {
    
if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    
      

       

   res.json(results);
      
    
});


}else{


res.json("not Authorized request");



}

})

});






app.get("/list/:lst_id/:email/", (req, res) => {




oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){






if(id!="false"){


lst_id=req.params.lst_id;
email=req.params.email;

get_email_data(lst_id,email,function(results){



res.json(results);


});



}else{


res.json("not Authorized request");



}


})


});





app.post("/list/:lst_id/add", (req, res) => {






oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){






if(id!="false"){

const filecon_conn = require("./confige/filecon.confige.js");


const list_conn = require("./confige/list.confige.js");






src=req.param('source');

if(src="API"){



hols_query="(";
  data_query="(";

for (const key in req.query) {
  

if(key=="substatus"){

   hols_query+=key+",";

   get_status_data(req.query[key],function(results){

data_query+="'"+results+"',";

   });



}else{

  hols_query+=key+",";

  


  
    data_query+="'"+req.query[key]+"',";

}

}

var datetime = new Date();
datetime=datetime.toISOString().slice(0,10);

console.log(datetime);

hols_query+="arch,crt_date,chg_date)";
data_query+="'0','"+datetime+"','"+datetime+"')";


filecon_conn.query('INSERT INTO `'+req.params.lst_id+'` '+hols_query+' value'+data_query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      
      
    }else{


var sql = "UPDATE filedetails SET  extra= extra+1 WHERE filename = '"+req.params.lst_id+"'";

console.log(sql);

list_conn.query(sql, function (err, result) {
    if (err) throw err;
    console.log(result.affectedRows + " record(s) updated");
  });

    console.log("inserted");


  }
  });


}

res.json("done");



}else{


res.json("not Authorized request");



}


})

});





app.delete("/list/:lst_id/delete/:email", (req, res) => {



oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){






if(id!="false"){



const filecon_conn = require("./confige/filecon.confige.js");




filecon_conn.query('UPDATE `'+req.params.lst_id+'` SET arch="1" WHERE email="'+req.params.email+'"', (err, results) => {
    
if (err) {
      console.log("error: ", err);
      
    }
    
      console.log("deletes");

       

   res.json("deleted");
      
    
});




}else{


res.json("not Authorized request");



}


})

});






//studio api managment






app.post("/studio/crt/folder/:fold_name", (req, res) => {

fold_name=req.params.fold_name;



oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){

console.log(id); 

if(id!="false"){


const axios = require('axios');




axios.get('https://studio.sycista.com/studio/ajaxfile/api.addnewdir.php', {
  params: {
    add_dir_name: fold_name,
    id:id
  }
})
  .then(response => {
    
    res.json(response.data);
  })
  .catch(error => {
    console.log(error);
  });



}else{



res.json("not Authorized request");


}








});

});






app.delete("/studio/delete/folder/:fold_name", (req, res) => {

fold_name=req.params.fold_name;



oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){

console.log(id); 

if(id!="false"){




var buffer = require('buffer/').Buffer;
const axios = require('axios');


fold_name=id+"^"+buffer.from(fold_name).toString('base64');


axios.get('https://studio.sycista.com/studio/ajaxfile/del_fold.php', {
  params: {
    fold_old_name: fold_name
    
  }
})
  .then(response => {
    
    res.json(response.data);
  })
  .catch(error => {
    console.log(error);
  });



}else{



res.json("not Authorized request");


}







});

});






app.post("/studio/:fold_name/up/url", (req, res) => {

fold_name=req.params.fold_name;

url_up=req.query.url;


oauth_fun_tokn(req.header('authorization').split(" ")[1],1,function(id){



if(id!="false"){





var buffer = require('buffer/').Buffer;
const axios = require('axios');


fold_name=id+"^"+buffer.from(fold_name).toString('base64');




axios.get('https://img.sycista.com/stc_img_url.php?dir_name='+fold_name+'&img_url='+url_up)
  .then(response => {
    
    res.json("vvvv");
  })
  .catch(error => {
    console.log(error);
  });



}else{



res.json("not Authorized request");


}







});

});







///api create api parts



app.get("/api/all/:id", (req, res) => {

const api_conn = require("./confige/api.confige.js");





api_conn.query('SELECT * FROM `api-key` where usr_id="'+req.params.id+'"', (err, results) => {
    

        if (err) {
      console.log("error: ", err);
      
    }



   res.json(results);
      
    
});





});












app.post("/api/add/mngc/:id", (req, res) => {

const api_conn = require("./confige/api.confige.js");



get_token(function(results){

token=results;

   });



user_id=req.params.id;
type='1';


api_conn.query('INSERT INTO `api-key` (usr_id,type,token,req) value ("'+user_id+'","1","'+token+'","0")', (err, results) => {
    

       if (err) {
      console.log("error: ", err);
      
    }



   res.json(token);
      
    
});





});


app.post("/api/add/send/:id", (req, res) => {

const api_conn = require("./confige/api.confige.js");

const send_api_conn = require("./confige/sending.data.confige.js");



get_token(function(results){

token=results;

   });



user_id=req.params.id;



api_conn.query('INSERT INTO `api-key` (usr_id,type,token,req) value ("'+user_id+'","2","'+token+'","0")', (err, results) => {
    

       if (err) {
      console.log("error: ", err);
      
    }

var crt_tbl_sql = "CREATE TABLE `"+token+"` (lst_id VARCHAR(30), con_id int(10),content_dt VARCHAR(40),tag VARCHAR(10))";
  send_api_conn.query(crt_tbl_sql, function (err, result) {
    if (err) throw err;
    

     res.json(token);

  });

  
      
    
});





});















// set port, listen for requests
app.listen(80, () => {
  console.log("Server is running on port 3000.");
});



function get_status_data(status,callback){

if(status=="subscribed"){

callback('1');

}

}






function get_email_data(lst_id,email,callback){




const filecon_conn = require("./confige/filecon.confige.js");




filecon_conn.query('SELECT * FROM `'+lst_id+'` WHERE email="'+email+'"', (err, results) => {
    

    var resultArray = Object.values(JSON.parse(JSON.stringify(results)))

       if(resultArray.length==1){


callback(resultArray);

       }else{

callback('false');

       }


   
    
});




}

function success_store_db(token,flg){

const api_conn = require("./confige/api.confige.js");




api_conn.query("UPDATE `api-key` SET  req=req+1 WHERE token='"+token+"'" , (err, results) => {
   

return 0;

});


}



function oauth_fun_tokn(token,flg,callback){

const api_conn = require("./confige/api.confige.js");




api_conn.query('SELECT * FROM `api-key` where token="'+token+'" and type="'+flg+'"' , (err, results) => {
   



var resultArray = Object.values(JSON.parse(JSON.stringify(results)));


if(resultArray.length=='1'){

  callback(resultArray[0].usr_id);


success_store_db(token,flg);


}else{

  callback('false');
}
});


}





 function get_token(callback) { 
            
            arr='abcdefghijh1234567890nkl';
ans='';

            for (var i = 24; i > 0; i--) { 
                ans +=  
                  arr[Math.floor(Math.random() * arr.length)]; 
            } 
              callback(ans); 
        }


